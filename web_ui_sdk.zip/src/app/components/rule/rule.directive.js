(function() {
  'use strict';

  angular
    .module('thingSpaceUiSdk')
    .directive('rulesConfig', rulesConfig)
	.filter('hourMinFilter', function () {
				return function (value) {
					  if (value === 1440) return 'All'
					  var h = parseInt(value / 60);
					  var m = parseInt(value % 60);
					  var hStr = (h > 0) ? h + 'hr'  : '';
					  var mStr = (m > 0) ? m + 'min' : '';
					  var glue = (hStr && mStr) ? ' ' : '';
					  return hStr + glue + mStr;
				};
	});
			
	
  /** @ngInject */
  function rulesConfig() {
    var directive = {
      restrict: 'E',
      templateUrl: 'app/components/rule/rule.html',
	  controller: function($rootScope,$scope,ApiFactory) {
		    $scope.ruleShow = true;
			$scope.ruleBtn = true;
			$scope.rulesRespMsg = true;
			$scope.applyRuleShow = true;
			$scope.deviceSelect ="";
			$scope.ruleEditBtn = true;
			$scope.applyRule ="";
			$scope.set_value ="";
			$scope.clear = function(){
				$scope.rulesRespMsg = true;
				$scope.ruleShow = true;
				$scope.ruleBtn = true;
			}
			$scope.clearApplyRule = function(){
				$scope.rulesRespMsg = true;
				//console.log($scope.applyRule);
				$scope.applyRuleShow = true;
				$scope.ruleBtn = true;
			}
			
			$scope.addSelectRule = function() {
				$scope.ex = $("#"+$scope.deviceSelect).text();
				
				if($scope.deviceSelect != "" && $scope.deviceSelect != "undefined"){
					$scope.ruleShow = false;
					if($scope.ruleShow == false && $scope.applyRuleShow == false){
						$scope.ruleBtn = false;
					}
				}
				else{
					$scope.ruleShow = true;
				}
            }
			$scope.addApplyRule = function() {
				$scope.applyRuleText = $("#"+$scope.applyRule).text();
				
				if($scope.applyRule != "" && $scope.applyRule != "undefined"){
					$scope.applyRuleShow = false;
					if($scope.ruleShow == false && $scope.applyRuleShow == false){
						$scope.ruleBtn = false;
					}
				}
				else{
					$scope.applyRuleShow = true;
				}
            }
			//console.log($scope.applyRuleShow);
			//console.log($scope.ruleShow);
			/**/
			
			$scope.creatingRule = function(){
				var in_device_id = $scope.deviceSelect;
				var out_device_id = $scope.applyRule;
				var value_range = [$scope.demo1.min,$scope.demo1.max];
				//console.log($scope.sliderConfig.userMinOne);
				//console.log($scope.sliderConfig.userMaxOne);
				var to_time = "9:00 AM"
				var from_time = "5:00 PM"
				var set_value = $scope.set_value;
				var alert = $scope.alert;
				//console.log(alert);
				
				 var data = $.param({
					 title:"drer3dd4dsdf523",
					 devices_in:$scope.deviceSelect,
					 from_time:"9:00 AM",
					 to_time:"5:00 PM",
					 range:[$scope.demo1.min,$scope.demo1.max],
					 devices_out:$scope.applyRule,
					 value:$scope.set_value,
					 alert:$scope.alert
				 });
				
				var ruleResp = ApiFactory.createRule(data);
				$scope.ruleResp = ruleResp.then (function(datares){
					   $scope.ruleResp = datares.data.message;
					   $scope.rulesRespMsg= false;
					   $scope.ruleBtn = true;
					   
				})
						
			}
			
			$scope.createNewRule = function(){
				$scope.clearApplyRule();
				$scope.clear();
				$scope.deviceSelect="";
				$scope.applyRule="";
				$scope.rulesRespMsg= true;
			}
	    }
    };
    return directive;
  }
})();
