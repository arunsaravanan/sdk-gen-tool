(function() {
  'use strict';
    describe('directive: map-view', function(){
        var element, scope;
         beforeEach(module('thingSpaceUiSdk'));
         beforeEach(inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
    
            element =
                '<div ng-if="key == map" class="mapview" map-view map-size="600,600" map-type={{maptype}} zoom-level="18" map-marker="dataPoints"></div>';
            
            scope.key = "map";
            scope.maptype = "google";
            
            element = $compile(element)(scope);
            scope.$digest();
         }));
         it('should render google maps', inject(function($compile, $rootScope) {
            var titles = elm.find('ul.nav-tabs li a');

            expect(titles.length).toBe(2);
            expect(titles.eq(0).text()).toBe('First Tab');
            expect(titles.eq(1).text()).toBe('Second Tab');
          }));
    });
})();