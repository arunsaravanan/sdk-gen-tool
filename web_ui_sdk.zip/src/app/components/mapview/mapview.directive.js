'use strict';

angular.module('thingSpaceUiSdk')
    .directive('mapView', function ($rootScope, $parse, $q, $window) {
    return {
        restrict: 'A',
        scope: {
            triggerFn: '='
        },
        controller: function($scope, $element,$attrs){
        $rootScope.mapViewinfo = function(dataPoint, devices){
		var mapWdth = $('.mapview').parent().innerWidth();
        $('.mapview').html('');
		$('.mapview').width(mapWdth-30);
		$("#mapId").remove();
        
        var mapType = $parse($attrs.mapType);
        var apiKey = $parse($attrs.apiKey);	
        //var mapSize = $parse(attrs.mapSize);
        var mapZoom = $parse($attrs.zoomLevel);	
        var mapMarkerData = dataPoint;
        var mapOptions,
          latitude = 42.360485,//dataPoint[0].latitude,
          longitude = -71.059963,//dataPoint[0].longitude,
          map,
          markers = [],//JSON.parse(JSON.stringify(dataPoint)),
          activeInfoWindow = null;
          
        latitude = parseFloat(latitude) && parseFloat(latitude, 10) || 41.074688;
        longitude = parseFloat(longitude) && parseFloat(longitude, 10) || -88.384294;
		var routeColor = ["#00C853","#F5933B","#00C853","#A80309"]; 
		
        var markersArr = [];
        var infoWindowsArr = [];
		//console.log(devices);
		for(var m in dataPoint){
			if(devices[dataPoint[m].category] == true){
				markers.push(dataPoint[m]);
			}			
		}
		//console.log(markers);
        switch($attrs.mapType){
            case "google":
            //loadScript().then(function () {
            var mapRoutes = [];
                    mapOptions = {
                  zoom: mapZoom($scope),
                  center: new google.maps.LatLng(latitude, longitude)
                };
                map = new google.maps.Map($element[0], mapOptions);
                
				var icnURL = null;
                for(var m in markers){
					if(markers[m].category == 'Light') {
						icnURL = "../assets/images/marker-icon.png";
					} else if(markers[m].category == 'Sensors') {
						icnURL = "../assets/images/marker-icon-sensors.png";
					} else if(markers[m].category == 'Cameras') {
						icnURL = "../assets/images/marker-icon-cameras.png";
					} else {
						icnURL = null;
					}
                    //console.log(markers[m].latitude);
                    var marker;
                    if(!markers[m].routes){
                        marker = new google.maps.Marker({
                            position: {lat: parseFloat(markers[m].latitude), lng: parseFloat(markers[m].longitude)},
                            map: map,
                            icon: icnURL,
                            title: markers[m].title
                        });
                        markersArr.push(marker);
                    }
                    if(markers[m].routes){
                        mapRoutes.push(markers[m].routes);
                    }

                    //console.log(marker.status);
					//console.log("tab-"+ $rootScope.tabValue);
					addInfoWindow(m, marker, "<h3 class='text-center'>"+markers[m].title+"</h3><p class='text-center'>"+markers[m].location+", "+markers[m].city+"</p>");
                }
                var locationsArr = [];
                var rcArr = [];
                for(var n in mapRoutes){
                    locationsArr = [];
                    for(var o in mapRoutes[n]){
                        locationsArr.push({lat:mapRoutes[n][o].latitude,lng:mapRoutes[n][o].longitude});                                                  
                    }
                    var routePath = new google.maps.Polyline({
                                    path: locationsArr,
                                    geodesic: true,
                                    strokeColor: routeColor[n],
                                    strokeOpacity: 1.0,
                                    strokeWeight: 5
                    });
                    rcArr.push(routePath);
                    routePath.setMap(map);
                }

				//$scope.$parent.injectedFn = $scope.triggerFn;
                $scope.$watch('triggerFn', function (value) {
                    /*Checking if the given value is not undefined*/
                    //console.log(value);
                    if(value){
                        $scope.Obj = value;
                        /*Injecting the Method*/
                        $scope.Obj.invoke = function(title, activeLink, indx, tab){
							var al = activeLink + indx;
							$('.allClass').removeClass('active');
							$('#'+ al).parent().addClass('active');
                            for(var m in markers){
								if(tab == 'alert' && markers[m].category != "Routes") {
									icnURL = "../assets/images/marker-icon-alert.png";
									markersArr[m].setIcon(icnURL);
								}
								if(markers[m].title == title && markers[m].category != "Routes")
                                {
                                    google.maps.event.trigger(markersArr[m], 'click');
									if(tab == 'alert'){
										if(markers[m].category == 'Light') {
											icnURL = "../assets/images/marker-icon-alert-light.png";
										} else if(markers[m].category == 'Sensors') {
											icnURL = "../assets/images/marker-icon-alert-sensors.png";
										} else if(markers[m].category == 'Cameras') {
											icnURL = "../assets/images/marker-icon-alert-camera.png";
										}
										markersArr[m].setIcon(icnURL);
									}
                                }                                
                            }
                        }
						$scope.Obj.toggleMarkers = function(e, devices, category, tab, idx){
							e.stopPropagation();
							$('#'+e.target.id).toggleClass('t-dev-disable');
							for(var m in markers){
                                if(markers[m].category == category && category != "Routes")
                                {
                                    markersArr[m].setVisible(!markersArr[m].visible);
									infoWindowsArr[m].close();
									
                                }
                            }
                            if(category == "Routes"){
                                for(var n in rcArr){
                                    rcArr[n].setVisible(!rcArr[n].visible)
                                }
                            }
                        }
						$scope.Obj.tabMarkers = function(tab){							
							for(var m in markers){
								if(markers[m].category == 'Light') {
									icnURL = "../assets/images/marker-icon.png";
								} else if(markers[m].category == 'Sensors') {
									icnURL = "../assets/images/marker-icon-sensors.png";
								} else if(markers[m].category == 'Cameras') {
									icnURL = "../assets/images/marker-icon-cameras.png";
								} else {
									icnURL = null;
								}
								if(tab == 'alerts') {
									icnURL = "../assets/images/marker-icon-alert.png";
								}
                                if(icnURL)
                                    markersArr[m].setIcon(icnURL);
							}
                        }
                    }    
                });
                function addInfoWindow(n, marker, message) {
                    var infoWindow = new google.maps.InfoWindow({
                        content: message
                    });
					infoWindowsArr.push(infoWindow);
                    google.maps.event.addListener(marker, 'click', function () {
                        if(activeInfoWindow != null)
                            activeInfoWindow.close();
                        infoWindow.open(map, marker);
                        activeInfoWindow = infoWindow;
                        $scope.$emit('marker_click');
                    });
                }
            //});
            break;
            case "mapquest":
            //loadScript().then(function () {
                var options = {
                  elt: $element[0],       // ID of map element on page
                  zoom: mapZoom($scope),                                  // initial zoom level of the map
                  latLng: { lat: latitude, lng: longitude },  // center of map in latitude/longitude
                  mtype: 'map',                              // map type (map, sat, hyb); defaults to map
                  bestFitMargin: 0,                          // margin offset from map viewport when applying a bestfit on shapes
                  zoomOnDoubleClick: true                    // enable map to be zoomed in when double-clicking
                };
                map = new MQA.TileMap(options);
                var mapRoutes = [];
                for(var m in markers){
                    if(markers[m] != undefined){
                        var pt = new MQA.Poi({ lat: markers[m].latitude, lng: markers[m].longitude });
                        pt.setRolloverContent('');
                        pt.setInfoTitleHTML(markers[m].title);
                        pt.setInfoContentHTML("<h4 class='text-left cob-pop'>"+markers[m].title+"</h4><p class='text-left'>"+markers[m].location+", "+markers[m].city+"</p>");
                        var icon = "";
                        if(markers[m].category == 'Light') {
                            icon = new MQA.Icon('../assets/images/marker-icon.png', 35, 38);
                        } else if(markers[m].category == 'Sensors') {
                            icon = new MQA.Icon('../assets/images/marker-icon-sensors.png', 35, 38);
                        } else if(markers[m].category == 'Cameras') {
                            icon = new MQA.Icon('../assets/images/marker-icon-cameras.png', 35, 38);
                        }else
                            icon = null;
                        addPoints(pt, m ,icon);
                        if(markers[m].category == "Routes")
                            mapRoutes.push(markers[m].routes);
                    }
                }
                var locationsArr = [], requestObj = {}, routesArr = [], rcArr = [];
                MQA.withModule('mousewheel','new-route','new-route-collection', function(){
                    map.enableMouseWheelZoom();
                    for(var n in mapRoutes){
                        locationsArr = [];
                        requestObj = {};
                        var routesStr = JSON.stringify(mapRoutes[n]);
                        routesStr = routesStr.replace(/{"latitude":/g,'');
                        routesStr = routesStr.replace(/"longitude":/g,'');
                        routesStr = routesStr.replace(/}/g,'');
                        routesStr = routesStr.replace(/[\[\]']+/g,'');
                        //console.log(routesStr);
                        routesArr = [];
                        routesArr = routesStr.split(",").map(Number);
                        //console.log(routesArr.length);
                        var rc = new MQA.RouteCollection({
                            pois: markersArr,
                            line: routesArr,
                            display: {
                              color: routeColor[n],
                              borderWidth: 5,
                              colorAlpha: 0.85
                            }
                          });
                        //console.log(rc);
                        rcArr.push(rc);
                        map.addShapeCollection(rc);
                        /*for(var o in mapRoutes[n]){
                            locationsArr.push({latLng:{lat:mapRoutes[n][o].latitude,lng:mapRoutes[n][o].longitude}});
                        }
                        requestObj["locations"] = locationsArr;
                        map.addRoute({
                            request: requestObj
                        });*/  
                    }
                });
                function addPoints(pt, n, icn){
                    //console.log(icn);
                    if(icn)
                    {   
                        pt.setIcon(icn);
                        map.addShape(pt);
                        markersArr.push(pt);
                    }
                    MQA.EventManager.addListener(pt, 'click', function(evt){
                        $scope.currentItem = n;
                        $scope.$emit('marker_click');
                    });
                }
                //map.bestFit();
                $scope.$watch('triggerFn', function (value) {
                    if(value){
                        $scope.Obj = value;
                        /*Injecting the Method*/
                        $scope.Obj.invoke = function(title, activeLink, indx, tab){
                            //console.log('invoke marker');
							var al = activeLink + indx;
							$('.allClass').removeClass('active');
							$('#'+ al).parent().addClass('active');
                            for(var m in markers){
								if(tab == 'alert') {
									icon = new MQA.Icon('../assets/images/marker-icon-alert.png', 35, 38);
                                    if(markersArr[m])
                                        markersArr[m].setIcon(icon);
								}
								if(markers[m].title == title)
                                {
                                    if(markersArr[m])
                                        MQA.EventManager.trigger(markersArr[m], 'click');
									if(tab == 'alert'){
										if(markers[m].category == 'Light') {
											icon = new MQA.Icon('../assets/images/marker-icon-alert-light.png', 60, 60);
										} else if(markers[m].category == 'Sensors') {
											icon = new MQA.Icon('../assets/images/marker-icon-alert-sensors.png', 60, 60);
										} else if(markers[m].category == 'Cameras') {
											icon = new MQA.Icon('../assets/images/marker-icon-alert-camera.png', 60, 60);
										}else
                                            icon = null;
                                        if(markersArr[m] && icon)    
                                            markersArr[m].setIcon(icon);
									}
                                }                                
                            }
                        }
						$scope.Obj.toggleMarkers = function(e, devices, category, tab, idx){
                            //console.log('toggle marker');
							e.stopPropagation();
							$('#'+e.target.id).toggleClass('t-dev-disable');
							for(var m in markers){
                                if(markers[m].category == category)
                                {
                                    //console.log(markersArr[m].visible);
                                    if(markersArr[m])
                                        markersArr[m].setVisible(!markersArr[m].visible);//arkersArr[m].visible;
                                    //MQA.BasicWindowManager.closeAll();
									//infoWindowsArr[m].close();
                                }
                            }
                            for(var n in rcArr){
                                //console.log(rcArr[n]);
                                rcArr[n].items[0].visible = !rcArr[n].items[0].visible;
                                //map.removeShapeCollection(rcArr[n]);
                            }
                        }
						$scope.Obj.tabMarkers = function(tab){
							//$('.mqabasicwnd-close').click();							
							//console.log('tab marker');
							for(var m in markers){
                                //MQA.BasicWindowManager.closeAll();
								if(tab == 'alerts') {
									icon = new MQA.Icon('../assets/images/marker-icon-alert.png', 35, 38);
									if(markersArr[m])
										markersArr[m].setIcon(icon);
								} 
                                if(tab != 'alerts') {
                                    //console.log(markers[m].category);
                                    if(markers[m].category == 'Light') {
                                        icon = new MQA.Icon('../assets/images/marker-icon.png', 35, 38);
                                    } else if(markers[m].category == 'Sensors') {
                                        icon = new MQA.Icon('../assets/images/marker-icon-sensors.png', 35, 38);
                                    } else if(markers[m].category == 'Cameras') {
                                        icon = new MQA.Icon('../assets/images/marker-icon-cameras.png', 35, 38);
                                    }else
                                        icon = null;
                                    if(icon)    
                                        markersArr[m].setIcon(icon);
                                }
							}
                        }
                    }    
                });
                //});
            break;
            case "bing":
                  //loadScript().then(function () {
                        var mapOptions = {
                                credentials : "AnTcaqBi2ypp0xI-OZNi4W_ik2KhjgpqioTAtXLC8GzkMBQRMlyxvxyTnd5b73im",
                                center: new Microsoft.Maps.Location(latitude, longitude),
                                zoom        :mapZoom($scope),
                                width:mapWdth,
                                height:510,
                                mapTypeId: Microsoft.Maps.MapTypeId.road                                
                            };
                        
                        
                        map = new Microsoft.Maps.Map($element[0],mapOptions);

                          var dataLayer = new Microsoft.Maps.EntityCollection();
                          map.entities.push(dataLayer);

                          var infoboxLayer = new Microsoft.Maps.EntityCollection();
                          map.entities.push(infoboxLayer);

                          var infobox = new Microsoft.Maps.Infobox(new Microsoft.Maps.Location(0, 0), { visible: false, offset: new Microsoft.Maps.Point(0, 20) });
                          infoboxLayer.push(infobox);
                          var mapRoutes = [];
                          AddData();
                            var locationsArr = [];
                            //var polygoncolor = new Microsoft.Maps.Color(255,245, 147, 59);
                            var stroke = 5;
                            for(var n in mapRoutes){
                                locationsArr = [];
                                for(var o in mapRoutes[n]){
                                    locationsArr.push(new Microsoft.Maps.Location(mapRoutes[n][o].latitude,mapRoutes[n][o].longitude));
                                }
                                var rgba = convertHex(''+routeColor[n],1);
                                var polygonColor = new Microsoft.Maps.Color(rgba.split(",")[0],rgba.split(",")[1],rgba.split(",")[2],rgba.split(",")[3]);
                                var Polyline = new Microsoft.Maps.Polyline(locationsArr,{fillColor:polygonColor, strokeColor: polygonColor, strokeThickness: stroke});
                                dataLayer.push(Polyline);
                            }
                          function AddData() {
                            var icnURL = "";
                            for(var m in markers){
                                if(markers[m].category == 'Light') {
                                    icnURL = "../assets/images/marker-icon.png";
                                } else if(markers[m].category == 'Sensors') {
                                    icnURL = "../assets/images/marker-icon-sensors.png";
                                } else if(markers[m].category == 'Cameras') {
                                    icnURL = "../assets/images/marker-icon-cameras.png";
                                }
                                if(markers[m].category == "Routes")
                                    mapRoutes.push(markers[m].routes);
                                 var pin;
                                 var pins =  pin+m;
                                 var visibleFlag = markers[m].routes == null ? true: false;
                                 pins = new Microsoft.Maps.Pushpin(new Microsoft.Maps.Location(markers[m].latitude, markers[m].longitude),{icon:icnURL, width: 35, height: 38, visible: visibleFlag});
                                  pins.Title = markers[m].title;
                                  pins.Description = "<p class='text-left'>"+markers[m].location+", "+markers[m].city+"</p>";//markers[m].description;
                                  Microsoft.Maps.Events.addHandler(pins, 'click', displayInfobox);
                                  dataLayer.push(pins);
                                  //markersArr.push(pins);
                              }
                          }
                          function convertHex(hex,opacity){
                                hex = hex.replace('#','');
                                var r = parseInt(hex.substring(0,2), 16);
                                var g = parseInt(hex.substring(2,4), 16);
                                var b = parseInt(hex.substring(4,6), 16);

                                var result = opacity*255 +','+r+','+g+','+b;
                                return result;
                            }
                          function displayInfobox(e) {
                            var eTarget = e.targetType && e.targetType == 'pushpin' ? e.target : e;
                            //console.log('disp: '+eTarget);
                              //if (e.targetType == 'pushpin') {
                                  $scope.$emit('marker_click');
                                  infobox.setLocation(eTarget.getLocation());
                                  infobox.setOptions({ visible: true, title: eTarget.Title, description: eTarget.Description });
                              //}
                          } 
                          ////////
                          var routesArr = [];
                          for(var i = 0; i < map.entities.getLength();i++){
                                var entity = map.entities.get(i);
                                for(var j = 0;j<entity.getLength();j++){
                                    var dLayer = entity.get(j);
                                    if(dLayer._locations)
                                        routesArr.push(dLayer);
                                    if(dLayer._icon)
                                        markersArr.push(dLayer);
                                }
                            }
                          $scope.$watch('triggerFn', function (value) {
                            if(value){
                                $scope.Obj = value;
                                /*Injecting the Method*/
                                $scope.Obj.invoke = function(title, activeLink, indx, tab){
                                    //console.log('invoke marker');
                                    var al = activeLink + indx;
                                    $('.allClass').removeClass('active');
                                    $('#'+ al).parent().addClass('active');
                                    for(var m in markers){
                                        if(tab == 'alert') {
                                            icon = '../assets/images/marker-icon-alert.png';
                                            markersArr[m].setOptions({icon : icon, width:35,height:38});
                                        }
                                        if(markers[m].title == title && markers[m].category != "Routes")
                                        {
                                            //console.log(markersArr[m]);
                                            //Microsoft.Maps.Events.invoke(markersArr[m], 'click', displayInfobox);
                                            displayInfobox(markersArr[m]);
                                            if(tab == 'alert'){
                                                if(markers[m].category == 'Light') {
                                                    icon = '../assets/images/marker-icon-alert-light.png';
                                                } else if(markers[m].category == 'Sensors') {
                                                    icon = '../assets/images/marker-icon-alert-sensors.png';
                                                } else if(markers[m].category == 'Cameras') {
                                                    icon = '../assets/images/marker-icon-alert-camera.png';
                                                }
                                                markersArr[m].setOptions({icon : icon, width:60,height:60});
                                            }
                                        }                                
                                    }
                                }
                                $scope.Obj.toggleMarkers = function(e, devices, category, tab, idx){
                                    //console.log('toggle marker');
                                    e.stopPropagation();
                                    $('#'+e.target.id).toggleClass('t-dev-disable');
                                    for(var m in markers){
                                        if(markers[m].category == category)
                                        {
                                            //console.log(markersArr[m].getVisible());
                                            markersArr[m].setOptions({visible: !markersArr[m].getVisible()});
                                            //MQA.BasicWindowManager.closeAll();
                                            //infoWindowsArr[m].close();
                                            
                                        }
                                    }
                                    if(category == "Routes"){
                                        for(var n in routesArr){
                                            routesArr[n].setOptions({visible:!routesArr[n].getVisible()});
                                        }
                                    }
                                }
                                $scope.Obj.tabMarkers = function(tab){
                                    //console.log('tab marker');
                                    for(var m in markers){
                                        //MQA.BasicWindowManager.closeAll();
                                        if(tab == 'alerts') {
                                            icon = '../assets/images/marker-icon-alert.png';
                                            markersArr[m].setOptions({icon : icon});
                                        } 
                                        if(tab != 'alerts') {
                                            //console.log(markers[m].category);
                                            if(markers[m].category == 'Light') {
                                                icon = '../assets/images/marker-icon.png';
                                            } else if(markers[m].category == 'Sensors') {
                                                icon = '../assets/images/marker-icon-sensors.png';
                                            } else if(markers[m].category == 'Cameras') {
                                                icon = '../assets/images/marker-icon-cameras.png';
                                            }
                                            markersArr[m].setOptions({icon : icon, width:35,height:38});
                                        }
                                    }
                                }
                            }    
                        });
                   // });               
            break;
		}
	}
    }
}
});