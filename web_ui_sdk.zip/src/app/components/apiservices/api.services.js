'use strict';

angular.module('thingSpaceUiSdk')
  .factory('ApiFactory', function($http) { 
    return {
       getConfig: function () {
            var promise = $http.get('./config.json') .then(function(response) {
            return response.data;
            }, function (error) {              
        })
        return promise;
       },
       getDevice: function () {
            var promise = $http.get('./app/data/devices.json') .then(function(response) {
            return response.data;
            }, function (error) {              
        })
        return promise;
       },
       getdeviceId: function (id) {
            var promise = $http.get('http://10.146.211.38:5000/api/v1/list/'+id) .then(function(response) {
            return response.data;
          }, function (error) {              
        })
        return promise;
       },
       getFilter: function (category) {
            var promise = $http.get('http://10.146.211.38:5000/api/v1/filter/'+category) .then(function(response) {
            return response.data;
          }, function (error) {              
        })
        return promise;
       },
	   createRule: function(data){
			return $http({
				headers: {'Content-Type': 'application/x-www-form-urlencoded'},
				url: 'http://10.146.211.38:5000/api/v1/rules',
				method: "POST",
				data: data,
			})
			.success(function(data) {
				return data.message;
			});
			return promise;
	   },
	   getRule: function (id) {
            var promise = $http.get('http://10.146.211.38:5000/api/v1/rules/'+id) .then(function(response) {
            return response.data;
          }, function (error) {              
        })
        return promise;
       }
    }     
});

  