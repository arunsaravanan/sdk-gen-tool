(function() {
  'use strict';

  angular
    .module('thingSpaceUiSdk')
})();
