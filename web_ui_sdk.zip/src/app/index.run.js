(function() {
  'use strict';
  angular
    .module('thingSpaceUiSdk')
    .run(runBlock);

  /** @ngInject */
  function runBlock($log) {

    $log.debug('runBlock end');
  }

})();
