//(function() {
    'use strict';

    angular
    .module('thingSpaceUiSdk')
    .controller('MainController', MainController)
	.filter('unique', function() {
	   return function(collection, keyname) {
		  var output = [], 
			  keys = [];

		  angular.forEach(collection, function(item) {
			  var key = item[keyname];
			  if(keys.indexOf(key) === -1) {
				  keys.push(key);
				  output.push(item);
			  }
		  });

		  return output;
	   };
	});
	 
	
    function MainController($rootScope, $scope,$http,ApiFactory,$location) {
		
		// Main Nav Controller
		$scope.navBar=[
			{Name:'Map View',link:"viewdevices",menuClass:"menu active"}
		];
		
        var vm = this;
		$scope.onoff='';
		$scope.dname='';
        $scope.Device = null;
		// just some values for the sliders
        		$scope.demo1 = {
        			min: 20,
        			max: 60
        		};
				
		$scope.sliderConfig = {
				min:  0,
			    max:  1440,
			    step: 10,
			    userMinOne: 0,
			    userMaxOne: 160
		};
		
		$scope.times = [
			 {
			   time: '20',
			   second_time: '50'
			 },
			 {
			   time: '50',
			   second_time: '10'
			 },
			 {
			   time: '30',
			   second_time: '15'
			 },
			 {
			   time: '10',
			   second_time: '180'
			 },
			 {
			   time: '85',
			   second_time: '290'
			 },
			 {
			   time: '75',
			   second_time: '60'
			 },
			 {
			   time: '95',
			   second_time: '45'
			 },
			 {
			   time: '100',
			   second_time: '120'
			 },
			 {
			   time: '80',
			   second_time: '120'
			 },
			 {
			   time: '200',
			   second_time: '18'
			 },
			 {
			   time: '260',
			   second_time: '22'
			 },
			 {
			   time: '120',
			   second_time: '66'
			 },
			 {
			   time: '62',
			   second_time: '78'
			 },
			 {
			   time: '68',
			   second_time: '92'
			 },
			 {
			   time: '5',
			   second_time: '57'
			 },
			 {
			   time: '116',
			   second_time: '140'
			 }
		];

        var category = 'Video';
        var id = '5787677e26e515301c0e9ff7';
        ApiFactory.getConfig().then(function(data){
            //console.log(data.components);
            $scope.uiConfig=data;
            $scope.components = $scope.uiConfig.components;
			$scope.devices = $scope.uiConfig.devices;
			for (var d in $scope.components){
                if($scope.components[d])
                {
					angular.element('#tabview li:first-child').addClass('active').addClass('in');	
					angular.element('.tab-content div:first-child').addClass('active').addClass('in');	
					break;
				}
            }
            for (var m in $scope.uiConfig.maptype){
                if($scope.uiConfig.maptype[m])
                    $rootScope.maptype = m;
            }
        }),
        ApiFactory.getDevice().then(function(data){
			 ApiFactory.getConfig().then(function(configData){	
				if($rootScope.mapViewinfo) 
					$rootScope.mapViewinfo(data, configData.devices);
			 });
			 $(window).resize(function(){
				var mapWdth = $('.mapview').parent().innerWidth();
				$('.mapview').width(mapWdth-30);
			}); 
          $scope.Device = data;
           $scope.lat = data[0].latitude;
          $scope.lang = data[0].longitude;	 
          $scope.dataPoints = data;
        });
        $scope.injectedFn = {};
        $scope.$on('marker_click', function () {});		
		$scope.getCount = function(i, device) {
			var iCount= iCount||0;
			for (var j = 0; j < $scope.Device.length; j++) {
				if (device == 'device'){
					if($scope.Device[j].category==i){
						iCount++;
					}
				}
				if (device == 'alert'){
					if($scope.Device[j].category == i && $scope.Device[j].status != 'Working'){
						iCount++;
					}
				}
				if (device == 'allAlert'){
					if($scope.Device[j].status != 'Working'){
						iCount++;
					}
				}
			}
            return iCount;
		}
    }
//})();