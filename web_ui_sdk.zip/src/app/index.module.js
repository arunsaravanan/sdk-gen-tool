(function() {
  'use strict';

  angular
    .module('thingSpaceUiSdk', ['ngAnimate', 'ui.router', 'ui.bootstrap', 'toastr','ui-rangeSlider']);
})();
