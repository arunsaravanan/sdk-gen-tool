(function() {
  'use strict';
//['thingSpaceUiSdk.services','thingSpaceUiSdk.controllers']
  angular
    .module('thingSpaceUiSdk')
    .config(config);

  /** @ngInject */
  function config($logProvider) {
    // Enable log
    $logProvider.debugEnabled(true);
  }

})();