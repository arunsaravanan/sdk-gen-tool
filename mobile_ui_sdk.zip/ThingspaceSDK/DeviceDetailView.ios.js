import React, { Component } from 'react';
import {
  StyleSheet,
  MapView,
  View,
  Text
} from 'react-native';


import Config from './TSConfig.json'
import WebServices from './WebServices'
import WebServiceManager from './WebServiceManager'

DigitalSelectedImage = require('./Icons/MapAnnotationIcons/digitalAnnotation_selected.png')
SensorSelectedImage = require('./Icons/MapAnnotationIcons/sensorAnnotation_selected.png')
CameraSelectedImage = require('./Icons/MapAnnotationIcons/cameraAnnotation_selected.png')
LightSelectedImage  = require('./Icons/MapAnnotationIcons/LightAnnotation_selected.png')

export default class DeviceDetailView extends Component {

  constructor(props) {
    super(props)
   console.log(props.data);
  }

  getDeiveIcon(category) {
    if(category == 'Light')
       return LightSelectedImage
    else if(category == 'Cameras')
       return CameraSelectedImage
    else if(category == 'Sensors')
       return SensorSelectedImage
    else if(category == 'Digital')
       return DigitalSelectedImage
    else if(category == 'EB')
       return DigitalSelectedImage
    else
       return DigitalSelectedImage
  }

  render() {
    return (
      <View style={styles.container}>
        <MapView style={styles.map}
          region={{
                latitude: parseFloat(this.props.data.latitude),
                longitude: parseFloat(this.props.data.longitude),
                latitudeDelta: 0.004,
                longitudeDelta: 0.004,
           }}
           annotations={[{
              latitude: parseFloat(this.props.data.latitude),
              longitude: parseFloat(this.props.data.longitude),
              title: "", //this.props.data.title,
              subtitle: "", //this.props.data.description,
              image: this.getDeiveIcon(this.props.data.category)
            }]}>
          </MapView>
          <View style={styles.detailView}>
            <Text style={styles.titleText}>{this.props.data.title}</Text>
            <Text style={styles.subTitleText}>{this.props.data.location}</Text>
            <Text style={styles.subTitleText}>Latitude: {this.props.data.latitude}</Text>
            <Text style={styles.subTitleText}>Longitude: {this.props.data.longitude}</Text>
          </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#F5FCFF',
  },
  map: {
    flex: 1,
  },
  detailView: {
    flex: 1,
    backgroundColor: 'white',
    flexDirection: 'column',
    justifyContent: 'center',
  },
  titleText: {
    color: '#4B4B4B',
    fontWeight: 'bold',
    fontSize: 20,
    textAlign: 'center',
    padding: 3,
  },
  subTitleText: {
    color: '#4B4B4B',
    fontSize: 18,
    textAlign: 'center',
    padding: 4,
  },
});
