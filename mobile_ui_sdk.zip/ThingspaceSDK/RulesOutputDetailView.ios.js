import React, { Component } from 'react';
import { Text,StyleSheet,TextInput, Picker,View,TouchableHighlight,Switch} from 'react-native';

export default class RulesOutputComponent extends Component {

  constructor() {
    super();

    this.state = {
     sensorValue:'0'};

  }

  render() {
    return (

      <View style={styles.container}>
        <View style={{
          flex: 1,
          flexDirection: 'column',
          justifyContent: 'center'
        }}>
          <Text style={styles.titleText}>Select Output Device to Apply Rule:</Text>
          <Picker
              style={styles.picker}>
              <Item label="hello" value="key0" />
              <Item label="world" value="key1" />
          </Picker>
          <View style={{ flexDirection: 'row'}}>
            <Text style={styles.titleText}>Set Sensor Value:</Text>
            <TextInput style={{height: 40, marginLeft:20,width:80,borderColor: 'gray', textColor: 'black',borderWidth: 1}}
            onChangeText={(sensorValue) => this.setState({sensorValue})}
            value={this.state.sensorValue}/>
          </View>
          <View style={{ flexDirection: 'row',}}>
            <Switch
            onValueChange={(value) => this.setState({falseSwitchIsOn: value})}
            style={{marginBottom: 10}}
            value={this.state.falseSwitchIsOn} />
            <Text style={styles.subText}>Send Alert</Text>
          </View>
          <View style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          }}>
            <TouchableHighlight onPress={this._onPressButton} style={styles.button}>
            <Text>Submit</Text>
            </TouchableHighlight>
          </View>
        </View>
      </View>

  );
  }
}
const Item = Picker.Item;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    marginRight: 20,
    marginLeft:20,
    marginTop:20,
    marginBottom:20
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom:20
  },
  picker: {

  },
  button: {
    backgroundColor: 'orange',
    height: 40, width:120,
    justifyContent: 'center',
    alignItems: 'center',
  },
  subText: {
    fontSize: 15,
    marginBottom:20,
    color: 'black'
  },
});
