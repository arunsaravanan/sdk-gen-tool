import React, { Component } from 'react';
import {
  Navigator,
  StyleSheet,
  BackAndroid
} from 'react-native';

import RulesListView from './RulesListView'

export default class RulesListViewNavigator extends Component {

constructor(props) {
    super(props);
    
  }

  createNewRule() {
    console.log("Create new rule button tapped");
  }

  render() {
    return (
       <RulesListView navigator={this.props.navigator} />
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#F5FCFF',
  },
});
