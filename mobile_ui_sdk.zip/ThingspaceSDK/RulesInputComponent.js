import React, { Component } from 'react';
import { BackAndroid,Navigator,PropTypes,TouchableHighlight, Text,StyleSheet,TextInput, TimePickerAndroid,View,UIExplorerBlock,TouchableWithoutFeedback, Picker } from 'react-native';
import RulesOutputComponent from './RulesOutputComponent';

export default class RulesInputComponent extends Component {


 constructor(props) {
    super(props);
    this.state = { 
     textFrom: 'From',
     textTo: 'To',
     sensorFrom:'0', 
     sensorTo:'100' };
    
  }
  
   componentDidMount() {
        console.log('mount');
        fetch(this.props.name)
      .then( response => console.log(response) )
}


  _onPressButton() {
  	 this.props.navigator.push({
            name: 'RulesOutputComponent',
            component: RulesOutputComponent,
             passProps: {
      name: 'property'
    }
        });
    console.log("You tapped the button!");
  }


  async showPicker(stateKey, options) {
    try {
      const {action, minute, hour} = await TimePickerAndroid.open(options);


      var newState = {};
      if (action === TimePickerAndroid.timeSetAction) {

        newState = _formatTime(hour, minute);
      } else if (action === TimePickerAndroid.dismissedAction) {
        newState = 'dismissed';
        console.log("Time 2 "+ newState);
      }

      console.log(`********** ${newState} ************`);
      this.setState({textFrom: newState});
    } catch ({code, message}) {
      console.warn(`Error in example '${stateKey}': `, message);
    }
  }

  async showToPicker(stateKey, options) {
    try {
      const {action, minute, hour} = await TimePickerAndroid.open(options);


      var newState = {};
      if (action === TimePickerAndroid.timeSetAction) {

        newState = _formatTime(hour, minute);
      } else if (action === TimePickerAndroid.dismissedAction) {
        newState = 'dismissed';
        console.log("Time 2 "+ newState);
      }

      console.log(`********** ${newState} ************`);
      this.setState({textTo: newState});
    } catch ({code, message}) {
      console.warn(`Error in example '${stateKey}': `, message);
    }
  }


  render() {
   return (
 
    <View style={styles.container}>

    <Text style={styles.titleText}>Select Input Device to Apply Rule:</Text>

    <Picker
            style={styles.picker}>
            <Item label="hello" value="key0" />
            <Item label="world" value="key1" />
          </Picker>

          <Text style={styles.titleText}>Time Range:</Text>
          <View style={{ flexDirection: 'row',justifyContent: 'center'}}>
          <View style={{flexDirection: 'row',marginRight: 20}}>
            <Text style={styles.titleText}>From:</Text>
              <TouchableWithoutFeedback
                onPress={this.showPicker.bind(this, 'simple')}>

            <View>
            <Text style={styles.subText}>{this.state.textFrom}</Text>
            </View>
          </TouchableWithoutFeedback>
        </View>
        <View style={{ flexDirection: 'row',marginLeft: 20}}>
          <Text style={styles.titleText}>To:</Text>
            <TouchableWithoutFeedback
                onPress={this.showToPicker.bind(this, 'simple')}>

            <View>
            <Text style={styles.subText}>{this.state.textTo}</Text>
            </View>
          </TouchableWithoutFeedback>
          </View>
      </View>
       <Text style={styles.titleText}>Sensor Range:</Text>

      <View style={{ flexDirection: 'row',justifyContent: 'center'}}>
      <View style={{flexDirection: 'row',marginRight: 20}}>
            <Text style={styles.titleText}>From:</Text>
            <TextInput
        style={{height: 40, width:80,borderColor: 'gray', textColor: 'black',borderWidth: 1}}
        onChangeText={(sensorFrom) => this.setState({sensorFrom})}
        value={this.state.sensorFrom}
      />
      </View>
      <View style={{ flexDirection: 'row',marginLeft: 20}}>
      <Text style={styles.titleText}>To:</Text>
            <TextInput
        style={{height: 40, width:80,borderColor: 'gray', borderWidth: 1}}
        onChangeText={(sensorTo) => this.setState({sensorTo})}
        value={this.state.sensorTo}
      />
      </View>
      </View>

      <View style={{
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
      }}>
               <TouchableHighlight onPress={this._onPressButton.bind(this)} style={styles.button}>
        <Text>Set Output Device</Text>
      </TouchableHighlight>
      </View>



      </View>
    );
  }
}

const Item = Picker.Item;

function _formatTime(hour, minute) {
  return hour + ':' + (minute < 10 ? '0' + minute : minute);
}

var styles = StyleSheet.create({
  picker: {

  },
});

const styles = StyleSheet.create({
  button: {
    backgroundColor: 'orange',    
    height: 40, width:120,
    justifyContent: 'center',
    alignItems: 'center',
  },
  color: {
    color:'red',
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom:20
  },
  subText: {
    fontSize: 20,
    marginBottom:20,
    color: 'black'
  },
  container: {
    flex: 1,
    backgroundColor: 'white',
    marginRight: 20,
    marginLeft:20,
    marginTop:20,
    marginBottom:20
  }
});