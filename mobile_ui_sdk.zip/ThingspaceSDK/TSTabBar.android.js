
import React, { Component } from 'react';
import TabNavigator from 'react-native-tab-navigator';
import { StyleSheet, Image } from 'react-native';

import Config from './TSConfig.json'

import MapNavigator from './MapNavigator';
import DeviceListViewNavigator from './DeviceListViewNavigator';
import RulesListViewNavigator from './RulesListViewNavigator';
import AlertListViewNavigator from './AlertListViewNavigator';
import NavigationControl from './NavigationControl';

export default class TSTabBar extends Component {

  constructor() {
    super();

    var components = Object.keys(Config['components']);
    var selectedComponents = components.filter(function (component) {return Config['components'][component] == true;});
    if(selectedComponents.length > 0) {
      this.state = {selectedTab: this.getComponentNameForId(selectedComponents[0])}
    }
  }

  render() {
    return (
      <TabNavigator
      tabBarStyle={{ backgroundColor: '#AD1600' , height: 60}}
      sceneStyle={{ paddingTop: 10 }}
      >
      {this.loadTabs()}
      </TabNavigator>
    );
  }


  getComponentNameForId(componentID) {
    if(componentID == 'map') {
      return 'MapNavigator';
    } if(componentID == 'list') {
      return 'DeviceListViewNavigator';
    }  if(componentID == 'alert') {
      return 'AlertListViewNavigator';
    } else {
      return 'RulesListViewNavigator';
    }
  }

  loadTabs() {
    var components = Object.keys(Config['components']);
    var selectedComponents = components.filter(function(component, i) {
      return Config['components'][component] == true;
    });

    var that = this;

    return selectedComponents.map(function (component, i){
      return that.getTabBarItemForComponent(component);
    });
  }

  getTabBarItemForComponent(componentID) {
    if(componentID == 'map') {
      return (  <TabNavigator.Item
		    selected={this.state.selectedTab === 'MapNavigator'}
		    title="Map"
        titleStyle ={styles.defaultSelectedTitle}
		    renderIcon={() => <Image source={require('./Icons/TabBarIcons/map.png')} />}
        icon = {styles.defaultSelectedIcon}
		    onPress={() => this.setState({ selectedTab: 'MapNavigator' })}>
		    <MapNavigator />
		  </TabNavigator.Item>);

    } else if(componentID == 'list') {
      return (<TabNavigator.Item
		    selected={this.state.selectedTab === 'DeviceListViewNavigator'}
		    title="Devices"
        titleStyle ={styles.defaultSelectedTitle}
		    renderIcon={() => <Image source={require('./Icons/TabBarIcons/device.png')} />}
        icon = {styles.defaultSelectedIcon}
		    onPress={() => this.setState({ selectedTab: 'DeviceListViewNavigator' })}>
		    <DeviceListViewNavigator />
		  </TabNavigator.Item>);

    }  else if(componentID == 'alert') {
      return ( <TabNavigator.Item
		    selected={this.state.selectedTab === 'AlertListViewNavigator'}
		    title="Alerts"
        titleStyle ={styles.defaultSelectedTitle}
		    renderIcon={() => <Image source={require('./Icons/TabBarIcons/alert.png')} />}
        icon = {styles.defaultSelectedIcon}
		    onPress={() => this.setState({ selectedTab: 'AlertListViewNavigator' })}>
		    <AlertListViewNavigator />
		  </TabNavigator.Item>);

    } else {
      return (<TabNavigator.Item
		    selected={this.state.selectedTab === 'NavigationControl'}
		    title="Rules"
        titleStyle ={styles.defaultSelectedTitle}
		    renderIcon={() => <Image source={require('./Icons/TabBarIcons/rule.png')} />}
		    onPress={() => this.setState({ selectedTab: 'NavigationControl' })}>
		    <NavigationControl />
		  </TabNavigator.Item>);
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#F5FCFF',
  },

  defaultSelectedTitle: {
   color: 'white',
  },

  defaultSelectedIcon: {
    tintColor: 'white',
  },


});
