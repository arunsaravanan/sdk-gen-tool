import React, { Component } from 'react';
import {
  NavigatorIOS,
  StyleSheet,
} from 'react-native';

import DeviceListView from './DeviceListView'

export default class ListViewNavigator extends Component {
  render() {
    return (
      <NavigatorIOS style={styles.container}
      barTintColor='#AD1600'
      titleTextColor='#FFFFFF'
        initialRoute={{
          title: 'Devices',
          component: DeviceListView,
        }}
      />
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#555555',
  },
});
