module.exports = {
  ALL_DEVICES_URL: 'http://10.146.211.38:5000/api/v1/list',
  VIDEO_URL: 'http://10.146.211.38:5000/api/v1/filter/Video',
  LIGHT_URL: 'http://10.146.211.38:5000/api/v1/filter/Light',
  DEVICE_DETAIL_URL: 'http://10.146.211.38:5000/api/v1/list/578766daf0c2fdf41f22d482',

  TEST_URL: 'https://raw.githubusercontent.com/facebook/react-native/master/docs/MoviesExample.json'
};
