import React, { Component } from 'react';
import { Navigator, StyleSheet, Text, View } from 'react-native';

import DeviceListView from './DeviceListView';
import DeviceDetailView from './DeviceDetailView';

export default class DeviceListViewNavigator extends Component {

  _renderScene(route, navigator) {
    if (route.id === 0) {
      return <DeviceListView navigator={navigator} {...route.passProps}  />
    } else if (route.id === 1) {
      return <DeviceDetailView navigator={navigator} {...route.passProps}  />
    }
  }

  render() {
    return (
      <Navigator style={styles.container}
        initialRoute={{
          id: 0
        }}
        renderScene={this._renderScene}
      />
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#F5FCFF',
  },
});
