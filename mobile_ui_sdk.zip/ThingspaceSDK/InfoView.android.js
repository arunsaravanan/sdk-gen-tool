import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View
} from 'react-native';

var TEST_URL = 'https://raw.githubusercontent.com/facebook/react-native/master/docs/MoviesExample.json'

import Config from './TSConfig.json'
import WebServiceManager from './WebServiceManager'
import WebServices from './WebServices'

import MapNavigator from './MapNavigator'

import WebData from './WebData.json'

export default class Test extends Component {

  componentDidMount() {
    // console.log(Config);
    console.log(WebServices.ALL_DEVICES_URL);

    WebServiceManager(TEST_URL)
    .then(function(data){
      console.log(data);
    });
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.welcome}>
          You have not selected any view options
        </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});


// fetch(TEST_URL)
//
// .then((response) => {
//     return response.json() // << This is the problem
// })
//
// .then((responseData) => { // responseData = undefined
//    return responseData;
//  })
//
// .then((data) => {
//    console.log(data.total);
//  });

[
  'John', 'Joel', 'James', 'Jimmy', 'Jackson', 'Jillian', 'Julie', 'Devin', 'Joel', 'James', 'Jimmy', 'Jackson', 'Jillian', 'Julie', 'Devin', 'Joel', 'James', 'Jimmy', 'Jackson', 'Jillian',
   'Julie', 'Devin', 'Joel', 'James', 'Jimmy', 'Jackson', 'Jillian', 'Julie', , 'Julie', 'Devin', 'Joel', 'James', 'Jimmy', 'Jackson', 'Jillian', 'Julie', 'Devin', 'Joel', 'James', 'Jimmy',
    'Jackson', 'Jillian', 'Julie', 'Devin', 'Joel', 'James', 'Jimmy',
    'Jackson', 'Jillian', 'Julie', 'Devin'
]
