import React, { Component } from 'react';
import {
  NavigatorIOS,
  Navigator,
  StyleSheet,
} from 'react-native';

import RulesListView from './RulesListView'

export default class RulesListViewNavigator extends Component {

  createNewRule() {
    console.log("Create new rule button tapped");
  }

  render() {
    return (
      <NavigatorIOS style={styles.container}
      barTintColor='#AD1600'
      titleTextColor='#FFFFFF'
        initialRoute={{
          title: 'Rules',
          component: RulesListView,
        }}
      />
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#F5FCFF',
  },
});
