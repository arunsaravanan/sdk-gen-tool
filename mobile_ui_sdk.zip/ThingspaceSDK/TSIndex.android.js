import {
  AppRegistry,
} from 'react-native';

import Config from './TSConfig.json'

import TSTabBar from './TSTabBar'
import AndroidMapNavigator from './MapNavigator'
import DeviceListViewNavigator from './DeviceListViewNavigator'
import InfoView from './InfoView'

var components = Object.keys(Config['components']);
var selectedComponents = components.filter(function (component) {return Config['components'][component] == true;});
console.log(selectedComponents);
console.disableYellowBox = true;

if(selectedComponents.length > 0) {
  AppRegistry.registerComponent('ReactSample', () => TSTabBar)
} else {
  AppRegistry.registerComponent('ReactSample', () => InfoView)
}