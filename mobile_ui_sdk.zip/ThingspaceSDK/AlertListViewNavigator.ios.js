import React, { Component } from 'react';
import {
  NavigatorIOS,
  StyleSheet,
} from 'react-native';

import AlertListView from './AlertListView'

export default class AlertViewNavigator extends Component {
  render() {
    return (
      <NavigatorIOS style={styles.container}
      barTintColor='#AD1600'
      tintColor='#AD1600'
      titleTextColor='#FFFFFF'
        initialRoute={{
          title: 'Alerts',
          component: AlertListView,
        }}
      />
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#F5FCFF',
  },
});
