import React, { Component } from 'react';
import {
  ListView,
  Text,
  View,
  StyleSheet,
  TouchableHighlight,
  Image
} from 'react-native';

import MapAnnotationView from './MapAnnotationView'
import WebServices from './WebServices'
import WebServiceManager from './WebServiceManager'
import DeviceDetailView from './DeviceDetailView'

import Config from './TSConfig.json'
import WebData from './WebData.json'

export default class DeviceListView extends Component {
  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

    var dsa = [];
    this.state = {
      dataSource: ds.cloneWithRows(dsa)
    };
  }

  componentDidMount() {

    var that = this;

    var devicesArray =  WebData.filter(function (device) {
      return device.category != "Routes";
    });

    const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    that.setState({ dataSource: ds.cloneWithRows(devicesArray) });

    /*
    var that = this;

    let url;
    if(Config.devices.lights && Config.devices.video) {
    url = WebServices.ALL_DEVICES_URL;
  } else if(Config.devices.lights && !Config.devices.video) {
  url = WebServices.LIGHT_URL;
} else if(!Config.devices.lights && Config.devices.video) {
url = WebServices.VIDEO_URL;
} else {
url = "";
}

WebServiceManager(url)
.then(function(data){
// console.log(data);

const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
that.setState({ dataSource: ds.cloneWithRows(data) });
});
*/
}

render() {
  return (
    <View style={styles.container}>
    <ListView
    automaticallyAdjustContentInsets={true}
    style={styles.listView}
    enableEmptySections={true}
    dataSource={this.state.dataSource}
    renderRow={(rowData) =>
      <TouchableHighlight
      onPress={()=> this.pressRow(rowData)}
      underlayColor = '#eee'
      style={styles.th}>

      <View style={styles.imageView}>
      {this.getDeiveIcon(rowData.category)}
      <View style={styles.cell}>
      <Text style={styles.titleText}>{rowData.title}</Text>
      <Text style={styles.subTitleText}>{rowData.location}</Text>
      </View>
      </View>


      </TouchableHighlight>}
      />
      </View>
    );
  }

  pressRow(rowData) {
    this.props.navigator.push({
      title: rowData.category,
      component: DeviceDetailView,
      passProps: {
        from: 'devicesPage',
        data:  rowData
      }
    });
  }

  getDeiveIcon(category) {
    if(category == 'Light') {
      return <Image style={styles.image} source={require('./Icons/ListViewIcons/Light.png')}/>
    } else if(category == 'Cameras') {
      return <Image style={styles.image} source={require('./Icons/ListViewIcons/camera.png')}/>
    } else if(category == 'Sensors') {
      return <Image style={styles.image} source={require('./Icons/ListViewIcons/sensor.png')}/>
    } else if(category == 'Digital') {
      return <Image style={styles.image} source={require('./Icons/ListViewIcons/digital.png')}/>
    } else if(category == 'EB') {
      return <Image style={styles.image} source={require('./Icons/ListViewIcons/EB.png')}/>
    } else {
      return <Image style={styles.image} source={require('./Icons/ListViewIcons/Light.png')}/>
    }
  }

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listView: {
    flex: 1,
    flexDirection: 'column',
  },
  titleText: {
    color:'#4B4B4B',
    fontWeight: 'bold',
    fontSize: 16,
    textAlign: 'left',
    padding: 5,

  },
  subTitleText: {
    color:'#4B4B4B',
    fontSize: 14,
    textAlign: 'left',
    padding: 5,
  },
  th: {
    borderBottomWidth: 0.5,
    borderBottomColor: '#AD1600',
    height: 80
  },
  cell: {
    alignSelf: 'center'
  },

  imageView: {
    flex: 1,
    flexDirection: 'row',
  },
  image: {
    width: 70,
    height: 70,
    alignSelf: 'center',
    padding: 5,
  }
});
