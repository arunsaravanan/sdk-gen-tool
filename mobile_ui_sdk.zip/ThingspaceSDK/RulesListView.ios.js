import React, { Component } from 'react';
import {
  ListView,
  Text,
  View,
  StyleSheet,
  TouchableHighlight
} from 'react-native';

import WebServices from './WebServices'
import WebServiceManager from './WebServiceManager'
import RulesInputDetailView from './RulesInputDetailView'

import Config from './TSConfig.json'
import RuleData from './RuleData.json'

export default class RulesListView extends Component {
  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

    var dsa = [];
    this.state = {
      dataSource: ds.cloneWithRows(dsa)
    };
  }

  componentDidMount() {
    var that = this;
    const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    that.setState({ dataSource: ds.cloneWithRows(RuleData) });

    // let url = WebServices.RULES_LIST_URL;
    //
    // WebServiceManager(url)
    // .then(function(data){
    //   console.log(data);
    //   const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    //   that.setState({ dataSource: ds.cloneWithRows(data) });
    // });
  }

  render() {
    return (
      <View style={styles.container}>
      <ListView
      automaticallyAdjustContentInsets={true}
      style={styles.listView}
      enableEmptySections={true}
      dataSource={this.state.dataSource}
      renderRow={(rowData) =>
        <TouchableHighlight
        onPress={()=> this.pressRow(rowData)}
        underlayColor = '#eee'>
        <View style={styles.cell}>
        <Text style={styles.titleText}>{rowData.title}</Text>
        </View>
        </TouchableHighlight>}
        />
        </View>
      );
    }

    pressRow(rowData) {
      // this.props.navigator.push({
      //     title: 'Rule - Input',
      //     component: RulesInputDetailView,
      //     passProps: {
      //       data:  rowData
      //     }
      // });
    }

  }

  const styles = StyleSheet.create({
    container: {
      flex: 1,
    },
    listView: {
      flex: 1,
      flexDirection: 'column',
    },
    titleText: {
      color: '#4B4B4B',
      fontWeight: 'bold',
      fontSize: 16,
      textAlign: 'left',
      padding: 5,
    },
    subTitleText: {
      color: 'black',
      fontSize: 14,
      textAlign: 'left',
      padding: 5,
    },
    cell: {
      borderBottomWidth: 0.5,
      borderBottomColor: '#AD1600',
      padding: 5,
      height: 44,
    },
  });
