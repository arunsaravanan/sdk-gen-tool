import React, { Component } from 'react';
import {
  StyleSheet,
  MapView,
  View,
  Text
} from 'react-native';

import Config from './TSConfig.json'
import WebData from './WebData.json'

DigitalSelectedImage = require('./Icons/MapAnnotationIcons/digitalAnnotation_selected.png')
SensorSelectedImage = require('./Icons/MapAnnotationIcons/sensorAnnotation_selected.png')
CameraSelectedImage = require('./Icons/MapAnnotationIcons/cameraAnnotation_selected.png')
LightSelectedImage  = require('./Icons/MapAnnotationIcons/LightAnnotation_selected.png')

DigitalUnselectedImage = require('./Icons/MapAnnotationIcons/digitalAnnotation.png')
SensorUnselectedImage = require('./Icons/MapAnnotationIcons/sensorAnnotation.png')
CameraUnselectedImage =require('./Icons/MapAnnotationIcons/cameraAnnotation.png')
LightUnselectedImage = require('./Icons/MapAnnotationIcons/LightAnnotation.png')

selectedIndex =  -1;

export default class MapAnnotationView extends Component {

  constructor(props) {
    super(props)

    this.state = {
      trafficArray: WebData.filter(function (device) {
        return device.category == "Routes";
      }),
      devicesArray: WebData.filter(function (device) {
        return device.category != "Routes";
      }),
      annotationsArray: [],
      routesArray: [],

      centerLatitude: 0,
      centerLongitude: 0,
      latitudeDelta: 0,
      longitudeDelta: 0,
    };
  }

  componentDidMount() {
    this.getCenterCoordinate();
    this.setState({ annotationsArray:this.loadAnnotations() });
    this.setState({ routesArray:this.loadRoutes() });
  }

  loadRoutes() {
    that = this;

    return this.state.trafficArray.map(function(device){
      return(
        coordinates = {
          coordinates:that.getCoordinates(device["routes"]),
          strokeColor:that.getTrafficColor(device),
          lineWidth: 3,
        });
      });
    }

    getCoordinates(routes) {
      return routes.map(function(route){
        var coordinate = {latitude:parseFloat(route["latitude"]), longitude:parseFloat(route["longitude"])};
        return(coordinate);
      });
    }

    getTrafficColor(device) {
      if(device["status"] =='freeflow') {
        return '#34AB43';
      } else if(device["status"] =='standstill') {
        return '#F5CB50';
      } else if(device["status"] =='stable flow with noticeable decline in free flow conditions') {
        return  '#72C39B';
      } else if(device["status"] =='high density but stable flow') {
        return '#F89A15';
      } else if(device["status"] =='conditions near capacity level') {
        return '#BC4F46';
      } else {
        return '#940E1B';
      }
    }

    getRegion() {
      return({
        latitude: this.state.centerLatitude,
        longitude: this.state.centerLongitude,
        latitudeDelta: this.state.latitudeDelta, // 0.003,
        longitudeDelta: this.state.longitudeDelta, //0.003,
      });
    }

    getCenterCoordinate() {
      that = this;
      var latitudeArray = [];
      var longitudeArray = [];

      // Get device coordinates
      for (var i = 0; i < that.state.devicesArray.length; i++) {
        var device =  that.state.devicesArray[i];
        latitudeArray.push(parseFloat(device.latitude));
        longitudeArray.push(parseFloat(device.longitude));
      }

      // Get route coordinates
      for (var i = 0; i < this.state.trafficArray.length; i++) {
        var device =  this.state.trafficArray[i];
        for (var j = 0; j < device.routes.length; j++) {
          var routes =  device.routes[j];
          latitudeArray.push(parseFloat(routes.latitude));
          longitudeArray.push(parseFloat(routes.longitude));
        }
      }


      var maxLatitude = (Math.max(...latitudeArray));
      var minLatitude = (Math.min(...latitudeArray));
      var maxLongitude = (Math.max(...longitudeArray));
      var minLongitude = (Math.min(...longitudeArray));

      that.setState({ centerLatitude:(maxLatitude + minLatitude) / 2 });
      that.setState({ centerLongitude:(maxLongitude + minLongitude) / 2 });
      that.setState({ latitudeDelta:(maxLatitude - minLatitude) + 0.001 });
      that.setState({ longitudeDelta:(maxLongitude - minLongitude) + 0.001 });

    }

    loadAnnotations() {
      that = this
      return that.state.devicesArray.map(function(annotation, index){
        return(that.createAnnotation(annotation, index));
      });
    }

    createAnnotation(annotation, index){
      return {
        latitude: annotation['latitude'],
        longitude: annotation['longitude'],
        image: that.getDeiveIcon(annotation['category'], index),
        onFocus: ()=> {
          selectedIndex = index;
          this.setState({ annotationsArray:this.loadAnnotations() });
        }
      };
    }

    getDeiveIcon(category, index) {
      if(category == 'Light') {
        if(selectedIndex == index) return LightSelectedImage;
        else return LightUnselectedImage

      } else if(category == 'Cameras') {
        if(selectedIndex == index) return CameraSelectedImage;
        else return CameraUnselectedImage

      } else if(category == 'Sensors') {
        if(selectedIndex == index) return SensorSelectedImage;
        else return SensorUnselectedImage

      } else if(category == 'Routes') {
        if(selectedIndex == index) return DigitalSelectedImage;
        else return DigitalUnselectedImage

      } else {
        if(selectedIndex == index) return LightSelectedImage;
        else return LightUnselectedImage

      }
    }

    render() {
      return (
        <MapView style={styles.container}
        region={this.getRegion()}
        annotations= {this.state.annotationsArray}
        overlays={this.state.routesArray}>
        </MapView>
      );
    }
  }

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      alignItems: 'stretch',
      backgroundColor: '#F5FCFF',
    },
  });
