import React, { Component } from 'react';
import {
  Navigator,
  StyleSheet,
} from 'react-native';

import AlertListView from './AlertListView'

export default class AlertViewNavigator extends Component {
  render() {
    return (
      <Navigator style={styles.container}
        initialRoute={{
          title: 'Alerts',
          index: 0,
        }}
        renderScene={(route, navigator) =>
            <AlertListView />
        }
      />
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#F5FCFF',
  },
});
