import MapView from 'react-native-maps';
import React, { Component } from 'react';
import { StyleSheet } from 'react-native';

import WebData from './WebData.json';

var myAnnotations = {};
var WebDataJSON = [];
var previousSelection = -1;


DigitalSelectedImage = require('./Icons/MapAnnotationIcons/digitalAnnotation_selected.png')
SensorSelectedImage = require('./Icons/MapAnnotationIcons/sensorAnnotation_selected.png')
CameraSelectedImage = require('./Icons/MapAnnotationIcons/cameraAnnotation_selected.png')
LightSelectedImage  = require('./Icons/MapAnnotationIcons/LightAnnotation_selected.png')

DigitalUnselectedImage = require('./Icons/MapAnnotationIcons/digitalAnnotation.png')
SensorUnselectedImage = require('./Icons/MapAnnotationIcons/sensorAnnotation.png')
CameraUnselectedImage =require('./Icons/MapAnnotationIcons/cameraAnnotation.png')
LightUnselectedImage = require('./Icons/MapAnnotationIcons/LightAnnotation.png')

export default class AndroidMapView extends Component {

  constructor(props) {
    super(props)

    this.state = {
      trafficArray: WebData.filter(function (device) {
        return device.category == "Routes";
      }),
      routeArray: [],
      deviceLoctaions: WebData.filter(function (device) {
        return device.category != "Routes";
      }),

      annotations : [],

      centerLatitude: 0,
      centerLongitude: 0,
      latitudeDelta: 0,
      longitudeDelta: 0,
    };
  }

  componentDidMount() {
    var that = this;

    that.getCenterCoordinate();


    that.setState({ deviceLoctaions:WebData });


    var devicesArray =  WebData.filter(function (device) {
      return device.category != "Routes";
    });

    for(var i in devicesArray) {

      var item = devicesArray[i];

      WebDataJSON.push({
        "title" : "",//item.title,
        "category"  : item.category,
        "description"       : "", //item.description,
        "longitude" : item.longitude,
        "latitude"  : item.latitude,
        "image"       : this.getMapIcon(item.category),
        "intRef"  : i
      });
    }
    this.state.annotations = WebDataJSON;
    // setTimeout(() => {
    //   this.refs.map.fitToElements(true,{});
    // }, 1000);

    that.loadRoutes();

  }

  loadRoutes() {
    that = this;

    var trafficArray = this.state.trafficArray

    for (var i = 0; i < trafficArray.length; i++) {
      var routes = trafficArray[i]["routes"];

      for (var j = 0; j < routes.length; j++) {
        that.state.routeArray.push(routes[j]);
      }

    }
    return that.state.routeArray;
  }

  pressMarker(marker) {
    if(previousSelection!=-1)
    {
      WebDataJSON[previousSelection].image = this.getMapIcon(WebDataJSON[previousSelection].category);
    }
    previousSelection = marker.intRef;
    WebDataJSON[marker.intRef].image = this.getDeviceListIcon(WebDataJSON[marker.intRef].category);

    this.setState({ annotations:WebDataJSON });
  }

  getDeviceListIcon(category) {
    if(category == 'Light') {
      return LightSelectedImage;
    } else if(category == 'Cameras') {
      return CameraSelectedImage;
    } else if(category == 'Sensors') {
      return SensorSelectedImage;
    } else if(category == 'Routes') {
      return DigitalSelectedImage;
    } else {
      return LightSelectedImage;
    }
  }

  getMapIcon(category) {
    if(category == 'Light') {
      return LightUnselectedImage
    } else if(category == 'Cameras') {
      return CameraUnselectedImage
    } else if(category == 'Sensors') {
      return SensorUnselectedImage
    } else if(category == 'Routes') {
      return DigitalUnselectedImage
    } else {
      return LightUnselectedImage
    }
  }

  getTrafficColor(device) {
    if(device["status"] =='freeflow') {
      return '#34AB43';
    } else if(device["status"] =='standstill') {
      return '#F5CB50';
    } else if(device["status"] =='stable flow with noticeable decline in free flow conditions') {
      return  '#72C39B';
    } else if(device["status"] =='high density but stable flow') {
      return '#F89A15';
    } else if(device["status"] =='conditions near capacity level') {
      return '#BC4F46';
    } else {
      return '#940E1B';
    }
  }

  getCoordinates(routes) {
    return routes.map(function(route){
      var coordinate = {latitude:parseFloat(route["latitude"]), longitude:parseFloat(route["longitude"])};
      return(coordinate);
    });
  }

  getOverLays() {
    that = this;
    var overlaysArray = this.state.trafficArray.map(function(device){
      return(
        <MapView.Polyline
        strokeWidth = {3}
        strokeColor = {that.getTrafficColor(device)}
        coordinates = {that.getCoordinates(device.routes)}
        />
      );
    });

    return overlaysArray;
  }

  getRegion() {
    return({
      latitude: this.state.centerLatitude,
      longitude: this.state.centerLongitude,
      latitudeDelta: this.state.latitudeDelta, // 0.003,
      longitudeDelta: this.state.longitudeDelta, //0.003,
    });
  }

  getCenterCoordinate() {
    that = this;
    var latitudeArray = [];
    var longitudeArray = [];

    // Get device coordinates
    for (var i = 0; i < that.state.deviceLoctaions.length; i++) {
      var device =  that.state.deviceLoctaions[i];
      latitudeArray.push(parseFloat(device.latitude));
      longitudeArray.push(parseFloat(device.longitude));
    }

    // Get route coordinates
    for (var i = 0; i < this.state.trafficArray.length; i++) {
      var device =  this.state.trafficArray[i];
      for (var j = 0; j < device.routes.length; j++) {
        var routes =  device.routes[j];
        latitudeArray.push(parseFloat(routes.latitude));
        longitudeArray.push(parseFloat(routes.longitude));
      }
    }

    var maxLatitude = (Math.max(...latitudeArray));
    var minLatitude = (Math.min(...latitudeArray));
    var maxLongitude = (Math.max(...longitudeArray));
    var minLongitude = (Math.min(...longitudeArray));

    that.setState({ centerLatitude:(maxLatitude + minLatitude) / 2 });
    that.setState({ centerLongitude:(maxLongitude + minLongitude) / 2 });
    that.setState({ latitudeDelta:(maxLatitude - minLatitude) + 0.001 });
    that.setState({ longitudeDelta:(maxLongitude - minLongitude) + 0.001 });

  }

  render() {
    return (
      <MapView
      ref="map"
      style={styles.container}
      initialRegion={this.getRegion()}
      >

      {this.state.annotations.map(marker => (
        <MapView.Marker
        coordinate={{latitude: parseFloat(marker.latitude),
          longitude: parseFloat(marker.longitude)}}
          title={marker.title}
          description={marker.description}
          onPress={() => this.pressMarker(marker)}
          image = {marker.image}
          />
        ))}

        {this.getOverLays()}
        </MapView>
      );
    }
  }


  const styles = StyleSheet.create({
    container: {
      flex: 1,
      alignItems: 'stretch',
      backgroundColor: '#F5FCFF',
    },
  });

  module.exports = AndroidMapView;
