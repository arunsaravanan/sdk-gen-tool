import { Navigator } from 'react-native';
import RulesListViewNavigator from './RulesListViewNavigator';
import RulesInputComponent from './RulesInputComponent';
import React, { Component } from 'react';


export default class NavigationControl extends
React.Component {
 render() {
        return (
            <Navigator
                initialRoute={{name: 'RulesListViewNavigator', component: RulesListViewNavigator}}
                configureScene={() => {
                    return Navigator.SceneConfigs.FloatFromRight;
                }}
                renderScene={(route, navigator) => {

                    if (route.component) {
                        return React.createElement(route.component, { navigator });
                    }
                }}
             />
        );
    }
}
