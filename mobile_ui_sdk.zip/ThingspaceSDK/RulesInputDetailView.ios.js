import React, { Component } from 'react';
import {
  Navigator,
  TouchableHighlight,
  Text,
  StyleSheet,
  TextInput,
  TimePickerAndroid,
  View,
  UIExplorerBlock,
  TouchableWithoutFeedback,
  Picker,
  Slider } from 'react-native';


import RulesOutputDetailView from './RulesOutputDetailView'

export default class RulesInputComponent extends Component {

  onPressButton() {
    console.log("You tapped the button!");
    this.props.navigator.push({
        title: 'Rule - Output',
        component: RulesOutputDetailView,
        passProps: {
          from: 'rulesInputPage',
          data:  this.props.data
        }
   });
  }


  constructor(props) {
     super(props);

     this.state = {
       fromTime: props.data.devices_in[0].from_time,
       toTime: props.data.devices_in[0].to_time,
       sensorFromValue:props.data.devices_in[0].value_range[0],
       sensorToValue:props.data.devices_in[0].value_range[1],
       sliderValue:0
     };
   }

  render() {
   return (


    <View style={styles.container}>

    <View style={[styles.inputDeviceContainer, {alignItems: 'center'}]}>
      <Text style={styles.titleText}>Selected Input Device</Text>
      <Text style={[styles.subText, {color: 'white'}]}>{this.props.data.devices_in[0].device_id}</Text>
    </View>

    <View style={styles.inputDeviceContainer}>
    <Text style={styles.titleText}>Time Range:</Text>

        <View style={[styles.miniContainer, {flexDirection: 'row', alignItems: 'center'}]}>
        <View style={[{flexDirection: 'row', flex:1}]}>
          <Text style={styles.subTitleText}>From:</Text>
          <TouchableWithoutFeedback>
          <View>
            <Text style={styles.subText}>{this.state.fromTime}</Text>
          </View>
          </TouchableWithoutFeedback>
          onPress={()=> this.Output(rowData)}
          </View>
          <View style={[{flexDirection: 'row', flex:1}]}>
            <Text style={styles.subTitleText}>To:</Text>
            <TouchableWithoutFeedback>
            <View>
              <Text style={styles.subText}>{this.state.fromTime}</Text>
            </View>
            </TouchableWithoutFeedback>
            </View>
          </View>
          </View>

  <View style={styles.inputDeviceContainer}>
    <Text style={[styles.titleText, {justifyContent: 'center'}]}>Sensor Range:</Text>


    <View style={[styles.miniContainer, {flexDirection: 'row'}]}>
      <Text style={[styles.subTitleText, {flex:1}]}>From:</Text>
      <Slider style={styles.slider}
          onValueChange={(value) =>this.setState({sliderValue:value})}
          maximumValue={100}
          minimumValue={0} />
    </View>

    <View style={styles.miniContainer}>
        <Text style={[styles.subTitleText, {flex:1}]}>To:</Text>
        <Slider style={styles.slider}
              onValueChange={(value) =>this.setState({sliderValue:value})}
              maximumValue={100}
              minimumValue={0} />
    </View>
  </View>


      <View style={styles.detailContainer}>
      <TouchableHighlight onPress={this.onForward} style={styles.button}>
        <Text>Output Device</Text>
      </TouchableHighlight>
      </View>
      </View>
    );
  }
}

const Item = Picker.Item;

function _formatTime(hour, minute) {
  return hour + ':' + (minute < 10 ? '0' + minute : minute);
}

var styles = StyleSheet.create({
  picker: {

  },
});

const styles = StyleSheet.create({
  button: {
    backgroundColor: 'orange',
    height: 40, width:120,
    justifyContent: 'center',
    alignItems: 'center',
  },
  color: {
    color:'red',
  },

  inputDeviceContainer: {
    backgroundColor: 'gray',
    padding:10,
    margin:10,
    alignItems: 'stretch',
    borderRadius: 5,
  },

  miniContainer: {
    backgroundColor: 'white',
    margin:5,
    alignItems: 'center',
    borderRadius: 5,
    flexDirection: 'row',
    height:50,
    justifyContent: 'center',
  },

  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom:20,
    color:'blue',
    marginLeft:20,
  },

  subTitleText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom:20,
    color:'blue',
    marginLeft:30,
  },

  subText: {
    fontSize: 20,
    marginBottom:20,
    color: 'black'
  },
  container: {
    flex: 1,
    backgroundColor: 'white',
    paddingTop:64
  },

  detailContainer: {
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },

  editorContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },

  slider: {
    flex:3,
    marginRight:15
  }
});
