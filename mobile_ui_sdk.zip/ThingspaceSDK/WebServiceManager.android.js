module.exports = function(url) {
  console.log(`URL send to server ${url}`);

  return fetch(url)
    .then(function(response) {
      return response.json()
    })
    .then(function(output){
      return output
    });
}