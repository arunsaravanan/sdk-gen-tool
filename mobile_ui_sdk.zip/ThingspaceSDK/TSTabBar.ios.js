import React, { Component } from 'react';
import {
  AppRegistry,
  TabBarIOS,
  NavigatorIOS,
  StyleSheet,
  View
} from 'react-native';

import MapAnnotationNavigator from './MapAnnotationNavigator'
import DeviceListViewNavigator from './DeviceListViewNavigator'
import RulesListViewNavigator from './RulesListViewNavigator'
import AlertListViewNavigator from './AlertListViewNavigator'

import Config from './TSConfig.json'

export default class TabBar extends Component {

  constructor() {
    super();

    var components = Object.keys(Config['components']);
    var selectedComponents = components.filter(function (component) {return Config['components'][component] == true;});
    if(selectedComponents.length > 0) {
      this.state = {selectedTab: this.getComponentNameForId(selectedComponents[0])}
    }
  }

  render() {
    return (
      <TabBarIOS barTintColor='#AD1600'
      tintColor='#FFFFFF'>
      {this.loadTabs()}
      </TabBarIOS>
    );
  }

  getComponentNameForId(componentID) {
    if(componentID == 'map') {
      return 'MapAnnotationNavigator';
    } if(componentID == 'list') {
      return 'DeviceListViewNavigator';
    }  if(componentID == 'alert') {
      return 'AlertListViewNavigator';
    } else {
      return 'RulesListViewNavigator';
    }
  }

  loadTabs() {
    var components = Object.keys(Config['components']);
    var selectedComponents = components.filter(function(component, i) {
      return Config['components'][component] == true;
    });

    var that = this;

    return selectedComponents.map(function (component, i){
      return that.getTabBarItemForComponent(component);
    });
  }

  getTabBarItemForComponent(componentID) {
    if(componentID == 'map') {
      return (  <TabBarIOS.Item
          title="Map"
          icon={require('./Icons/TabBarIcons/map.png')}
          selected={this.state.selectedTab === 'MapAnnotationNavigator'}
          onPress={() => this.setState({selectedTab: "MapAnnotationNavigator"})}>
        <MapAnnotationNavigator />
        </TabBarIOS.Item>);

    } else if(componentID == 'list') {
      return (<TabBarIOS.Item
        title="Devices"
        icon={require('./Icons/TabBarIcons/device.png')}
        selected={this.state.selectedTab === 'DeviceListViewNavigator'}
        onPress={() => this.setState({selectedTab: "DeviceListViewNavigator"})}>
      <DeviceListViewNavigator />
      </TabBarIOS.Item>);

    }  else if(componentID == 'alert') {
      return (<TabBarIOS.Item
        title="Alerts"
        icon={require('./Icons/TabBarIcons/alert.png')}
        selected={this.state.selectedTab === 'AlertListViewNavigator'}
        onPress={() => this.setState({selectedTab: "AlertListViewNavigator"})}>
      <AlertListViewNavigator />
      </TabBarIOS.Item>);

    } else {
      return (<TabBarIOS.Item
        title="Rules"
        icon={require('./Icons/TabBarIcons/rule.png')}
        selected={this.state.selectedTab === 'RulesListViewNavigator'}
        onPress={() => this.setState({selectedTab: "RulesListViewNavigator"})}>
      <RulesListViewNavigator />
      </TabBarIOS.Item>);
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#F5FCFF',
  },
});
