import {
  AppRegistry,
} from 'react-native';

import Config from './TSConfig.json'
import TSTabBar from './TSTabBar'
import InfoView from './InfoView'

var components = Object.keys(Config['components']);
var selectedComponents = components.filter(function (component) {return Config['components'][component] == true;});
console.log(selectedComponents);
console.disableYellowBox = true;

if(selectedComponents.length > 0) {
  AppRegistry.registerComponent('Cityspace', () => TSTabBar)
} else {
  AppRegistry.registerComponent('Cityspace', () => InfoView)
}
