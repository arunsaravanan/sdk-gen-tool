import React, { Component } from 'react';
import {
  NavigatorIOS,
  StyleSheet,
} from 'react-native';

import MapAnnotationView from './MapAnnotationView'

export default class MapAnnotationNavigator extends Component {
  render() {
    return (
      <NavigatorIOS style={styles.container}
      barTintColor='#AD1600'
      titleTextColor='#FFFFFF'
        initialRoute={{
          title: 'Map',
          component: MapAnnotationView,
        }}
      />
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: '#F5FCFF',
  },
});
