import React, { Component } from 'react';
import {
  ListView,
  Text,
  View,
  StyleSheet,
  Navigator,
  TouchableHighlight,
  BackAndroid
} from 'react-native';

import RuleData from './RuleData.json'
import WebServices from './WebServices'
import WebServiceManager from './WebServiceManager'
import RulesInputComponent from './RulesInputComponent'

import Config from './TSConfig.json'

export default class RulesListView extends Component {
  constructor(props) {
    super(props);
    this.pressRow = this.pressRow.bind(this);
    const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

    var dsa = [];
    this.state = {
      dataSource: ds.cloneWithRows(RuleData)
    };
     BackAndroid.addEventListener('hardwareBackPress', function() {
            this.props.navigator.pop();
            return true;
        }.bind(this));
  }

  componentDidMount() {
    console.log("**** componentDidMount ****");

    var that = this;

    let url;
    if(Config.devices.lights && Config.devices.video) {
      url = WebServices.RULES_LIST_URL;
     } else {
      url = "";
    }

    WebServiceManager(url)
    .then(function(data){
      console.log(data);

      const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
      that.setState({ dataSource: ds.cloneWithRows(RuleData) });
    });
  }

  render() {
    return (
      <View style={styles.container}>
        <ListView
          automaticallyAdjustContentInsets={true}
          style={styles.listView}
          enableEmptySections={true}
          dataSource={this.state.dataSource}
          renderRow={(rowData) =>
            <TouchableHighlight
              // onPress={this.pressRow.bind(this)}
              underlayColor = '#eee'>
                <View style={styles.cell}>
                  <Text style={styles.titleText}>{rowData.title}</Text>
                </View>
            </TouchableHighlight>}
        />
      </View>
    );
  }

  pressRow() {
    this.props.navigator.push({
            name: 'RulesInputComponent',
            component: RulesInputComponent,
             passProps: {
      name: 'property'
    }
        });
  }

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listView: {
    flex: 1,
    flexDirection: 'column',
  },
  titleText: {
    color: '#4B4B4B',
    fontWeight: 'bold',
    fontSize: 16,
    textAlign: 'left',
    padding: 5,
  },
  subTitleText: {
    color: 'black',
    fontSize: 14,
    textAlign: 'left',
    padding: 5,
  },
  cell: {
    borderBottomWidth: 0.5,
    borderBottomColor: '#AD1600',
    padding: 5,
  },
});
