import React, { Component } from 'react';
import {
  ListView,
  Text,
  View,
  StyleSheet,
  TouchableHighlight
} from 'react-native';

import WebData from './WebData.json'
import WebServices from './WebServices'
import WebServiceManager from './WebServiceManager'

import Config from './TSConfig.json'

export default class AlertListView extends Component {
  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

    var dsa = [];
    this.state = {
      dataSource: ds.cloneWithRows(WebData)
    };
  }

  componentDidMount() {
    var that = this;

    let url;
    if(Config.devices.lights && Config.devices.video) {
      url = WebServices.ALL_DEVICES_URL;
    } else if(Config.devices.lights && !Config.devices.video) {
      url = WebServices.LIGHT_URL;
    } else if(!Config.devices.lights && Config.devices.video) {
      url = WebServices.VIDEO_URL;
    } else {
      url = "";
    }

    WebServiceManager(url)
    .then(function(data){
      console.log(data);

      const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
      that.setState({ dataSource: ds.cloneWithRows(WebData) });
    });
  }

  render() {
    return (
      <View style={styles.container}>
        <ListView
          automaticallyAdjustContentInsets={true}
          style={styles.listView}
          enableEmptySections={true}
          dataSource={this.state.dataSource}
          renderRow={(rowData) =>
            <View style={styles.cell}>
              <View style={[styles.statusBar, this.setColorForStatusBar(rowData.status)]}></View>
              <View style={styles.detailView}>
                <Text style={styles.titleText}>{rowData.title}</Text>
                <Text style={this.setColorForStatus(rowData.status)}>Status: {rowData.status}</Text>
              </View>
            </View>
              }
        />
      </View>
    );
  }

  pressRow(rowData) {
    this.props.navigator.push({
        title: rowData.category,
        component: DeviceDetailView,
        passProps: {
          from: 'devicesPage',
          data:  rowData
        }
    });
  }

  getStatusColor(status) {
    var textColor;
    if(status == 'On') {
       textColor= 'green';
    } else if(status == 'Off') {
       textColor= 'green';
    }  else if(status == 'Not working') {
       textColor= 'red';
    }  else if(status == 'Working') {
       textColor= 'green';
    }  else if(status == 'Alerted cops') {
       textColor= 'orange';
    }

    return textColor;
  }

  setColorForStatusBar(status) {
    console.log(status);

    color = this.getStatusColor(status);
    var style = {
      backgroundColor: color,
    }
    return style;
  }

  setColorForStatus(status) {
    console.log(status);

    textColor = this.getStatusColor(status);
    var style = {
      color: textColor,
      fontSize: 14,
      textAlign: 'left',
      padding: 5
    }
    return style;
  }

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listView: {
    flex: 1,
    flexDirection: 'column',
  },
  titleText: {
    color: '#4B4B4B',
    fontWeight: 'bold',
    fontSize: 16,
    textAlign: 'left',
    paddingTop: 10,
    paddingLeft: 5,
  },
  subTitleText: {
    color: '#4B4B4B',
    fontSize: 14,
    textAlign: 'left',
    paddingBottom: 10,
    paddingLeft: 5,
  },
  statusBar: {
    width: 5,
    backgroundColor: 'blue',
  },

  detailView: {
    flex: 1,
    paddingTop: 10,
    paddingBottom: 10,
  },

  cell: {
    borderBottomWidth: 0.5,
    borderBottomColor: '#AD1600',
    flexDirection: 'row',
  }

});
